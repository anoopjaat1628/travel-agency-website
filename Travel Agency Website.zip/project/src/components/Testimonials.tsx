import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah M.',
    location: 'New York, USA',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=200',
    tour: 'Greek Island Hopper',
    rating: 5,
    text: "Absolute perfection from start to finish. Our guide Dimitri was extraordinary — knowledgeable, warm, and full of stories. Santorini at sunset will live in my heart forever.",
  },
  {
    name: 'James K.',
    location: 'London, UK',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=200',
    tour: 'African Safari',
    rating: 5,
    text: "Witnessing a pride of lions at sunrise in the Serengeti was transcendent. Horizons handled every detail seamlessly. I've traveled with many agencies — none compare.",
  },
  {
    name: 'Mei L.',
    location: 'Singapore',
    avatar: 'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&w=200',
    tour: 'Himalayan Trek',
    rating: 5,
    text: "I was nervous about high-altitude trekking, but the team was so supportive and prepared. The views from Annapurna base camp left me speechless. A truly life-changing trip.",
  },
];

export default function Testimonials() {
  return (
    <section className="py-24 px-6 bg-slate-900 relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url("https://images.pexels.com/photos/1430676/pexels-photo-1430676.jpeg?auto=compress&cs=tinysrgb&w=1920")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      <div className="absolute inset-0 bg-slate-900/80" />

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-sky-400 font-semibold text-sm uppercase tracking-widest mb-3">
            Traveler Stories
          </p>
          <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight">
            Journeys that stay with you
          </h2>
          <p className="mt-4 text-slate-400 text-lg max-w-xl mx-auto">
            Real stories from real travelers who experienced the world with Horizons.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-colors duration-300"
            >
              <Quote className="w-8 h-8 text-sky-400 mb-6" />
              <p className="text-slate-300 text-sm leading-relaxed mb-8">{t.text}</p>

              <div className="flex items-center gap-1 mb-6">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>

              <div className="flex items-center gap-4 pt-6 border-t border-white/10">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <p className="font-semibold text-white">{t.name}</p>
                  <p className="text-slate-400 text-xs">{t.location}</p>
                  <p className="text-sky-400 text-xs mt-0.5">{t.tour}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-2xl overflow-hidden">
          <div className="relative h-64 md:h-80">
            <img
              src="https://images.pexels.com/photos/3769138/pexels-photo-3769138.jpeg?auto=compress&cs=tinysrgb&w=1920"
              alt="Travelers"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-sky-900/80 to-transparent flex items-center">
              <div className="px-10 md:px-16 max-w-xl">
                <p className="text-sky-300 text-sm font-semibold uppercase tracking-widest mb-3">
                  Ready to explore?
                </p>
                <h3 className="text-3xl md:text-4xl font-bold text-white mb-6">
                  Your next adventure begins here
                </h3>
                <a
                  href="#"
                  className="inline-flex items-center gap-2 px-8 py-4 bg-white text-slate-900 font-semibold rounded-full hover:bg-sky-100 transition-colors duration-200"
                >
                  Start Planning
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
