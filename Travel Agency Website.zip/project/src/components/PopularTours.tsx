import { Clock, Users, Star, Heart, ArrowRight } from 'lucide-react';
import { useState } from 'react';

const tours = [
  {
    id: 1,
    title: 'Greek Island Hopper',
    region: 'Europe',
    image: 'https://images.pexels.com/photos/1603650/pexels-photo-1603650.jpeg?auto=compress&cs=tinysrgb&w=800',
    duration: '12 days',
    groupSize: '8-16',
    rating: 4.9,
    reviews: 412,
    price: 3499,
    oldPrice: 3999,
    badge: 'Best Seller',
    badgeColor: 'bg-amber-500',
  },
  {
    id: 2,
    title: 'Himalayan Trekking Adventure',
    region: 'Asia',
    image: 'https://images.pexels.com/photos/1365425/pexels-photo-1365425.jpeg?auto=compress&cs=tinysrgb&w=800',
    duration: '15 days',
    groupSize: '6-12',
    rating: 4.8,
    reviews: 289,
    price: 2899,
    oldPrice: null,
    badge: 'New',
    badgeColor: 'bg-emerald-500',
  },
  {
    id: 3,
    title: 'African Safari & Gorilla Trek',
    region: 'Africa',
    image: 'https://images.pexels.com/photos/36577/africa-animal-big-game-elephant.jpg?auto=compress&cs=tinysrgb&w=800',
    duration: '10 days',
    groupSize: '4-10',
    rating: 5.0,
    reviews: 176,
    price: 5299,
    oldPrice: 5999,
    badge: 'Luxury',
    badgeColor: 'bg-sky-600',
  },
  {
    id: 4,
    title: 'Patagonia End of the World',
    region: 'South America',
    image: 'https://images.pexels.com/photos/3757144/pexels-photo-3757144.jpeg?auto=compress&cs=tinysrgb&w=800',
    duration: '8 days',
    groupSize: '8-14',
    rating: 4.7,
    reviews: 321,
    price: 2299,
    oldPrice: null,
    badge: 'Adventure',
    badgeColor: 'bg-orange-500',
  },
];

export default function PopularTours() {
  const [wishlisted, setWishlisted] = useState<number[]>([]);

  const toggleWishlist = (id: number) => {
    setWishlisted((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  return (
    <section className="py-24 px-6 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-sky-600 font-semibold text-sm uppercase tracking-widest mb-3">
            Curated Experiences
          </p>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight">
            Popular Tours
          </h2>
          <p className="mt-4 text-slate-500 text-lg max-w-2xl mx-auto">
            From thrilling expeditions to serene retreats — every journey crafted to perfection.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-7">
          {tours.map((tour) => (
            <div
              key={tour.id}
              className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group flex flex-col"
            >
              <div className="relative overflow-hidden h-52">
                <img
                  src={tour.image}
                  alt={tour.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <span
                  className={`absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-bold text-white ${tour.badgeColor}`}
                >
                  {tour.badge}
                </span>
                <button
                  onClick={() => toggleWishlist(tour.id)}
                  className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center hover:bg-white transition-colors"
                  aria-label="Add to wishlist"
                >
                  <Heart
                    className={`w-4 h-4 transition-colors ${
                      wishlisted.includes(tour.id) ? 'fill-rose-500 text-rose-500' : 'text-slate-400'
                    }`}
                  />
                </button>
                <div className="absolute bottom-3 left-3">
                  <span className="text-white/80 text-xs font-medium">{tour.region}</span>
                </div>
              </div>

              <div className="p-5 flex flex-col flex-1">
                <h3 className="font-bold text-slate-800 text-base leading-snug mb-3">{tour.title}</h3>

                <div className="flex items-center gap-4 text-slate-500 text-xs mb-4">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> {tour.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" /> {tour.groupSize} pax
                  </span>
                </div>

                <div className="flex items-center gap-1.5 mb-4">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span className="font-semibold text-slate-800 text-sm">{tour.rating}</span>
                  <span className="text-slate-400 text-xs">({tour.reviews})</span>
                </div>

                <div className="mt-auto flex items-center justify-between pt-4 border-t border-slate-100">
                  <div>
                    <span className="text-sky-600 font-bold text-lg">${tour.price.toLocaleString()}</span>
                    {tour.oldPrice && (
                      <span className="text-slate-400 text-sm line-through ml-1.5">${tour.oldPrice.toLocaleString()}</span>
                    )}
                    <p className="text-slate-400 text-xs">per person</p>
                  </div>
                  <button className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold rounded-xl transition-colors duration-200">
                    Book Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a
            href="#"
            className="inline-flex items-center gap-2 px-8 py-4 border-2 border-sky-600 text-sky-600 font-semibold rounded-full hover:bg-sky-600 hover:text-white transition-all duration-200"
          >
            Explore all tours <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
