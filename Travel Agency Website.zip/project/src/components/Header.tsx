import { useState } from 'react';
import { Menu, X, Globe, Phone } from 'lucide-react';

interface HeaderProps {
  scrolled: boolean;
}

export default function Header({ scrolled }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Globe
            className={`w-7 h-7 transition-colors duration-300 ${scrolled ? 'text-sky-600' : 'text-white'}`}
            strokeWidth={1.5}
          />
          <span
            className={`text-xl font-bold tracking-tight transition-colors duration-300 ${
              scrolled ? 'text-slate-800' : 'text-white'
            }`}
          >
            Horizons
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-8">
          {['Destinations', 'Tours', 'Experiences', 'About', 'Contact'].map((item) => (
            <a
              key={item}
              href="#"
              className={`text-sm font-medium transition-colors duration-300 hover:text-sky-400 ${
                scrolled ? 'text-slate-600' : 'text-white/90'
              }`}
            >
              {item}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <a
            href="tel:+18005551234"
            className={`flex items-center gap-1.5 text-sm font-medium transition-colors duration-300 ${
              scrolled ? 'text-slate-600' : 'text-white/90'
            }`}
          >
            <Phone className="w-4 h-4" />
            +1 800 555 1234
          </a>
          <a
            href="#"
            className={`px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-300 ${
              scrolled
                ? 'bg-sky-600 text-white hover:bg-sky-700'
                : 'bg-white text-slate-800 hover:bg-white/90'
            }`}
          >
            Book Now
          </a>
        </div>

        <button
          className="md:hidden"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          {menuOpen ? (
            <X className={`w-6 h-6 ${scrolled ? 'text-slate-800' : 'text-white'}`} />
          ) : (
            <Menu className={`w-6 h-6 ${scrolled ? 'text-slate-800' : 'text-white'}`} />
          )}
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 shadow-xl">
          <nav className="flex flex-col px-6 py-4 gap-4">
            {['Destinations', 'Tours', 'Experiences', 'About', 'Contact'].map((item) => (
              <a
                key={item}
                href="#"
                className="text-slate-700 font-medium hover:text-sky-600 transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                {item}
              </a>
            ))}
            <a
              href="#"
              className="mt-2 px-5 py-3 bg-sky-600 text-white text-center rounded-full font-semibold"
            >
              Book Now
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
