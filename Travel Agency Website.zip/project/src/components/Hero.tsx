import { useState, useEffect } from 'react';
import { ChevronDown, MapPin, Calendar, Users, Search } from 'lucide-react';

const slides = [
  {
    image: 'https://images.pexels.com/photos/2325446/pexels-photo-2325446.jpeg?auto=compress&cs=tinysrgb&w=1920',
    location: 'Santorini, Greece',
    tagline: 'Where azure meets infinity',
  },
  {
    image: 'https://images.pexels.com/photos/3586966/pexels-photo-3586966.jpeg?auto=compress&cs=tinysrgb&w=1920',
    location: 'Bali, Indonesia',
    tagline: 'Discover paradise on earth',
  },
  {
    image: 'https://images.pexels.com/photos/2422259/pexels-photo-2422259.jpeg?auto=compress&cs=tinysrgb&w=1920',
    location: 'Patagonia, Argentina',
    tagline: 'Adventure awaits at the end of the world',
  },
  {
    image: 'https://images.pexels.com/photos/1660995/pexels-photo-1660995.jpeg?auto=compress&cs=tinysrgb&w=1920',
    location: 'Kyoto, Japan',
    tagline: 'Step into living history',
  },
];

export default function Hero() {
  const [current, setCurrent] = useState(0);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setFading(true);
      setTimeout(() => {
        setCurrent((prev) => (prev + 1) % slides.length);
        setFading(false);
      }, 600);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const slide = slides[current];

  return (
    <section className="relative h-screen min-h-[700px] flex flex-col">
      <div
        className={`absolute inset-0 transition-opacity duration-700 ${fading ? 'opacity-0' : 'opacity-100'}`}
      >
        <img
          src={slide.image}
          alt={slide.location}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60" />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center flex-1 text-center px-6 pt-20">
        <div
          className={`transition-all duration-700 ${fading ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <MapPin className="w-4 h-4 text-sky-400" />
            <span className="text-sky-300 font-medium text-sm tracking-widest uppercase">
              {slide.location}
            </span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight mb-4 max-w-4xl">
            Explore the World's <span className="text-sky-400">Hidden</span> Wonders
          </h1>
          <p className="text-white/80 text-lg md:text-xl max-w-xl mx-auto mb-10">
            {slide.tagline}
          </p>
        </div>

        <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl p-3 flex flex-col md:flex-row gap-2">
          <div className="flex items-center gap-3 flex-1 px-4 py-3 bg-slate-50 rounded-xl">
            <MapPin className="w-5 h-5 text-sky-500 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wide">Destination</p>
              <input
                type="text"
                placeholder="Where to?"
                className="w-full text-slate-800 font-medium bg-transparent outline-none text-sm placeholder:text-slate-400"
              />
            </div>
          </div>
          <div className="flex items-center gap-3 flex-1 px-4 py-3 bg-slate-50 rounded-xl">
            <Calendar className="w-5 h-5 text-sky-500 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wide">Dates</p>
              <input
                type="text"
                placeholder="When?"
                className="w-full text-slate-800 font-medium bg-transparent outline-none text-sm placeholder:text-slate-400"
              />
            </div>
          </div>
          <div className="flex items-center gap-3 flex-1 px-4 py-3 bg-slate-50 rounded-xl">
            <Users className="w-5 h-5 text-sky-500 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wide">Travelers</p>
              <input
                type="text"
                placeholder="How many?"
                className="w-full text-slate-800 font-medium bg-transparent outline-none text-sm placeholder:text-slate-400"
              />
            </div>
          </div>
          <button className="flex items-center justify-center gap-2 px-8 py-4 bg-sky-600 hover:bg-sky-700 text-white font-semibold rounded-xl transition-colors duration-200">
            <Search className="w-4 h-4" />
            Search
          </button>
        </div>

        <div className="flex items-center gap-3 mt-8">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => { setFading(true); setTimeout(() => { setCurrent(i); setFading(false); }, 300); }}
              className={`rounded-full transition-all duration-300 ${
                i === current ? 'bg-white w-8 h-2' : 'bg-white/40 w-2 h-2 hover:bg-white/70'
              }`}
            />
          ))}
        </div>
      </div>

      <div className="relative z-10 flex justify-center pb-8 animate-bounce">
        <ChevronDown className="w-7 h-7 text-white/70" />
      </div>
    </section>
  );
}
