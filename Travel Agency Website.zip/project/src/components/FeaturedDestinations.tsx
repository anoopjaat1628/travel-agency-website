import { ArrowRight, Star } from 'lucide-react';

const destinations = [
  {
    name: 'Santorini',
    country: 'Greece',
    image: 'https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.9,
    reviews: 2140,
    tag: 'Romantic',
    price: 'From $1,299',
  },
  {
    name: 'Kyoto',
    country: 'Japan',
    image: 'https://images.pexels.com/photos/161401/fushimi-inari-taisha-shrine-kyoto-japan-161401.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.8,
    reviews: 1870,
    tag: 'Cultural',
    price: 'From $1,599',
  },
  {
    name: 'Machu Picchu',
    country: 'Peru',
    image: 'https://images.pexels.com/photos/2356045/pexels-photo-2356045.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.9,
    reviews: 3210,
    tag: 'Adventure',
    price: 'From $1,899',
  },
  {
    name: 'Amalfi Coast',
    country: 'Italy',
    image: 'https://images.pexels.com/photos/1538177/pexels-photo-1538177.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.7,
    reviews: 1640,
    tag: 'Scenic',
    price: 'From $1,499',
  },
  {
    name: 'Safari, Serengeti',
    country: 'Tanzania',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 5.0,
    reviews: 980,
    tag: 'Wildlife',
    price: 'From $2,999',
  },
  {
    name: 'Maldives',
    country: 'Indian Ocean',
    image: 'https://images.pexels.com/photos/1483053/pexels-photo-1483053.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.9,
    reviews: 2780,
    tag: 'Luxury',
    price: 'From $2,499',
  },
];

const tagColors: Record<string, string> = {
  Romantic: 'bg-rose-100 text-rose-700',
  Cultural: 'bg-amber-100 text-amber-700',
  Adventure: 'bg-emerald-100 text-emerald-700',
  Scenic: 'bg-sky-100 text-sky-700',
  Wildlife: 'bg-orange-100 text-orange-700',
  Luxury: 'bg-slate-100 text-slate-700',
};

export default function FeaturedDestinations() {
  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14">
          <div>
            <p className="text-sky-600 font-semibold text-sm uppercase tracking-widest mb-3">
              Top Picks
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight">
              Featured Destinations
            </h2>
            <p className="mt-4 text-slate-500 text-lg max-w-xl">
              Handpicked destinations loved by thousands of travelers around the world.
            </p>
          </div>
          <a
            href="#"
            className="hidden md:flex items-center gap-2 text-sky-600 font-semibold hover:gap-3 transition-all duration-200 mt-6 md:mt-0"
          >
            View all destinations <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {destinations.map((dest) => (
            <div
              key={dest.name}
              className="group relative rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-400 cursor-pointer"
            >
              <div className="relative h-72 overflow-hidden">
                <img
                  src={dest.image}
                  alt={dest.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <span
                  className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-semibold ${tagColors[dest.tag]}`}
                >
                  {dest.tag}
                </span>
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h3 className="text-white text-xl font-bold">{dest.name}</h3>
                  <p className="text-white/70 text-sm">{dest.country}</p>
                </div>
              </div>
              <div className="bg-white p-5 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="font-semibold text-slate-800 text-sm">{dest.rating}</span>
                  <span className="text-slate-400 text-sm">({dest.reviews.toLocaleString()})</span>
                </div>
                <span className="text-sky-600 font-bold text-sm">{dest.price}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center md:hidden">
          <a href="#" className="inline-flex items-center gap-2 text-sky-600 font-semibold">
            View all destinations <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
