import { useState } from 'react';
import { Send, CheckCircle } from 'lucide-react';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setEmail('');
    }
  };

  return (
    <section className="py-20 px-6 bg-sky-600 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <p className="text-sky-200 font-semibold text-sm uppercase tracking-widest mb-3">
          Stay Inspired
        </p>
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
          Get travel inspiration delivered to your inbox
        </h2>
        <p className="text-sky-100 text-lg mb-10 max-w-xl mx-auto">
          Exclusive deals, destination guides, and early access to new tours — join 40,000+ travel enthusiasts.
        </p>

        {submitted ? (
          <div className="flex items-center justify-center gap-3 bg-white/20 text-white rounded-2xl py-5 px-8">
            <CheckCircle className="w-6 h-6 text-emerald-300" />
            <span className="font-semibold text-lg">You're on the list! Welcome aboard.</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              required
              className="flex-1 px-6 py-4 rounded-xl bg-white/20 text-white placeholder:text-sky-200 border border-white/30 focus:outline-none focus:border-white focus:bg-white/30 transition-colors"
            />
            <button
              type="submit"
              className="flex items-center justify-center gap-2 px-8 py-4 bg-white text-sky-600 font-bold rounded-xl hover:bg-sky-50 transition-colors duration-200 whitespace-nowrap"
            >
              <Send className="w-4 h-4" />
              Subscribe
            </button>
          </form>
        )}

        <p className="text-sky-200 text-xs mt-4">
          No spam. Unsubscribe anytime. We respect your privacy.
        </p>
      </div>
    </section>
  );
}
