import { Shield, Headphones, Award, Globe, Clock, CreditCard } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Safe & Secure',
    description: 'Your safety is our top priority. All tours are fully insured with 24/7 emergency support.',
    color: 'bg-sky-50 text-sky-600',
  },
  {
    icon: Award,
    title: 'Expert Guides',
    description: 'Our certified local guides bring destinations to life with insider knowledge and passion.',
    color: 'bg-amber-50 text-amber-600',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Dedicated concierge support before, during, and after your journey — always a call away.',
    color: 'bg-emerald-50 text-emerald-600',
  },
  {
    icon: CreditCard,
    title: 'Best Price Guarantee',
    description: "Found a better price? We'll match it. Travel confidently knowing you're getting the best deal.",
    color: 'bg-rose-50 text-rose-600',
  },
  {
    icon: Globe,
    title: '200+ Destinations',
    description: 'From hidden gems to iconic landmarks — we offer journeys to over 200 destinations worldwide.',
    color: 'bg-teal-50 text-teal-600',
  },
  {
    icon: Clock,
    title: 'Flexible Booking',
    description: 'Life changes. Change your plans freely up to 30 days before departure with no penalties.',
    color: 'bg-orange-50 text-orange-600',
  },
];

const stats = [
  { value: '50K+', label: 'Happy Travelers' },
  { value: '200+', label: 'Destinations' },
  { value: '15+', label: 'Years Experience' },
  { value: '4.9', label: 'Average Rating' },
];

export default function WhyChooseUs() {
  return (
    <section className="py-24 px-6 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <p className="text-sky-600 font-semibold text-sm uppercase tracking-widest mb-3">
              Why Horizons
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight mb-6">
              Travel with confidence and joy
            </h2>
            <p className="text-slate-500 text-lg leading-relaxed mb-8">
              For over 15 years, Horizons has been crafting unforgettable travel experiences. We believe every journey should be effortless, immersive, and deeply personal.
            </p>
            <a
              href="#"
              className="inline-flex items-center gap-2 px-8 py-4 bg-sky-600 text-white font-semibold rounded-full hover:bg-sky-700 transition-colors duration-200"
            >
              Our Story
            </a>
          </div>

          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.pexels.com/photos/3278215/pexels-photo-3278215.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Travelers"
                className="rounded-2xl object-cover h-56 w-full"
              />
              <img
                src="https://images.pexels.com/photos/1167021/pexels-photo-1167021.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Adventure"
                className="rounded-2xl object-cover h-56 w-full mt-10"
              />
              <img
                src="https://images.pexels.com/photos/2007401/pexels-photo-2007401.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Culture"
                className="rounded-2xl object-cover h-56 w-full -mt-10"
              />
              <img
                src="https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Landscape"
                className="rounded-2xl object-cover h-56 w-full"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-sky-600 text-white px-6 py-4 rounded-2xl shadow-xl">
              <p className="text-3xl font-bold">15+</p>
              <p className="text-sky-200 text-sm">Years of Excellence</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20 py-10 border-y border-slate-100">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-4xl font-bold text-slate-900 mb-1">{stat.value}</p>
              <p className="text-slate-500 text-sm">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="p-6 rounded-2xl border border-slate-100 hover:border-sky-200 hover:shadow-md transition-all duration-300 group"
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${feature.color} group-hover:scale-110 transition-transform duration-200`}>
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 text-lg mb-2">{feature.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
