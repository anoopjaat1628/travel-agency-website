import { Globe, Facebook, Instagram, Twitter, Youtube, MapPin, Phone, Mail } from 'lucide-react';

const destinations = ['Santorini, Greece', 'Bali, Indonesia', 'Kyoto, Japan', 'Maldives', 'Patagonia', 'Serengeti'];
const tours = ['Island Hopping', 'Safari Tours', 'Mountain Treks', 'City Escapes', 'Luxury Retreats', 'Family Adventures'];
const company = ['About Us', 'Our Team', 'Careers', 'Press', 'Sustainability', 'Partners'];

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-6 pt-20 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-5">
              <Globe className="w-7 h-7 text-sky-400" strokeWidth={1.5} />
              <span className="text-xl font-bold text-white tracking-tight">Horizons</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-6 max-w-xs">
              Crafting extraordinary travel experiences since 2009. We believe the world is too beautiful not to explore.
            </p>
            <div className="flex items-center gap-3">
              {[Facebook, Instagram, Twitter, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center hover:bg-sky-600 transition-colors duration-200"
                  aria-label="Social media"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-5">Destinations</h4>
            <ul className="space-y-3">
              {destinations.map((d) => (
                <li key={d}>
                  <a href="#" className="text-slate-400 hover:text-sky-400 text-sm transition-colors duration-200">
                    {d}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-5">Tours</h4>
            <ul className="space-y-3">
              {tours.map((t) => (
                <li key={t}>
                  <a href="#" className="text-slate-400 hover:text-sky-400 text-sm transition-colors duration-200">
                    {t}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-5">Company</h4>
            <ul className="space-y-3 mb-8">
              {company.map((c) => (
                <li key={c}>
                  <a href="#" className="text-slate-400 hover:text-sky-400 text-sm transition-colors duration-200">
                    {c}
                  </a>
                </li>
              ))}
            </ul>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-2.5">
              <li className="flex items-center gap-2 text-slate-400 text-sm">
                <MapPin className="w-4 h-4 text-sky-400 flex-shrink-0" />
                123 Explorer Ave, New York
              </li>
              <li className="flex items-center gap-2 text-slate-400 text-sm">
                <Phone className="w-4 h-4 text-sky-400 flex-shrink-0" />
                +1 800 555 1234
              </li>
              <li className="flex items-center gap-2 text-slate-400 text-sm">
                <Mail className="w-4 h-4 text-sky-400 flex-shrink-0" />
                hello@horizons.travel
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-sm">
            2024 Horizons Travel Co. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map((link) => (
              <a key={link} href="#" className="text-slate-500 hover:text-slate-300 text-xs transition-colors duration-200">
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
